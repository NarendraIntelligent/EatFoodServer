package com.example.narendra.eatfoodserver.Interface;

import android.view.View;

/**
 * Created by narendra on 2/20/2018.
 */

public interface ItemClickListener {
    void onClick(View view,int position,boolean isLongClick);
}
