package com.example.narendra.eatfoodserver.Model;

/**
 * Created by narendra on 3/13/2018.
 */

public class Result {
    public String message_id;
}
